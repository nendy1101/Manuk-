token = "04a78d8c612b85990cc9bcceff07f2cccb9f781a4d6871cb7448bd21bc873968"

coin = "TRX"

"""
hilo : high or low, hi = high, lo = low
"""

betset = {
    "bet":"0.00010000",
    "chance":50,
     "high/low":"high", # high / low
    "if win":1,
    "if lose":2,
    "reset if win":1,
    "reset if lose":0,
    "target profit":1000,
    "target balance":10000
}
